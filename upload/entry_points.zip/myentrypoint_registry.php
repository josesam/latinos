<?php


$entry_point_registry['alertas_prospectos'] = array('file' => 'alertas_prospectos.php', 'auth' => false);
$entry_point_registry['alertas_aplicaciones'] = array('file' => 'alertas_applicaciones.php', 'auth' => false);


?>
