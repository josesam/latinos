<?php

$app_list_strings['call_status_dom']=array (
  'Planned' => 'Запланирован',
  'Held' => 'Принят',
  'Not Held' => 'Не принят',
  'Missed' => 'Пропущен',
  'In Limbo' => 'В процессе',
);