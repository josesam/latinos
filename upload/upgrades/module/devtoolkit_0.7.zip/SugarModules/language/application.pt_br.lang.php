<?PHP
$app_strings['LBL_DEVTOOLKIT_MESSAGE_DUPLICATE_FIELD'] = 'Valor Duplicado';
$app_strings['ERR_DEVTOOLKIT_QUERY_DUPLICATE_FIELD'] = 'Erro ao recuperar campos �nicos para a extens�o Campos Duplicados do DevToolKit: ';
?>
