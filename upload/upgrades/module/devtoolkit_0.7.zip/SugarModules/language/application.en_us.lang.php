<?PHP
$app_strings['LBL_DEVTOOLKIT_MESSAGE_DUPLICATE_FIELD'] = 'Duplicate value';
$app_strings['ERR_DEVTOOLKIT_QUERY_DUPLICATE_FIELD'] = 'Error retrieving unique fields for DevToolKit Duplicate Fields extension: ';
?>
