<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*******************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/**
 * Description:  Defines Spanish latam language pack for the base application.
 * $Id: sp_ve.lang.php,v 1.8 2010/06/29 10:20:29 carlose Exp $
 * Source: SugarCRM 6.0
 * Contributor(s): Carlos Espinosa (carlose@proactinfo.com)
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tipos de Impuestos',
  'LBL_MODULE_TITLE' => 'Tipos de Impuestos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Tipos de Impuestos',
  'LBL_LIST_FORM_TITLE' => 'Listar Tipos de Impuestos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Tipo de Impuesto',
  'LBL_TAXRATE' => 'Tipo de Impuesto:',
  'LBL_LIST_NAME' => 'Nombre de Tipo de Impuesto',
  'LBL_NAME' => 'Nombre de Tipo de Impuesto:',
  'LBL_LIST_LIST_ORDER' => 'Orden',
  'LBL_LIST_ORDER' => 'Orden:',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_STATUS' => 'Estado:',
  'LBL_LIST_VALUE' => 'Porcentaje',
  'LBL_VALUE' => 'Porcentaje(%):',
  'LNK_NEW_SHIPPER' => 'Lista de transportistas',
  'LNK_NEW_TAXRATE' => 'Lista de Tipos de Impuestos',
  'NTC_DELETE_CONFIRMATION' => '¿Está seguro de eliminar este registro?',
  'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar el tipo de impuesto.',
  'NTC_STATUS' => 'Establezca el estado a Inactivo para eliminar este tipo de impuesto de las listas desplegables de Tipo de Impuesto',
  'NTC_LIST_ORDER' => 'Defina el orden en que este Tipo de Impuesto aparecerá en las listas desplegables',
  'taxrate_status_dom' => 
  array (
    'Active' => 'Activo',
    'Inactive' => 'Inactivo',
  ),
);


?>
